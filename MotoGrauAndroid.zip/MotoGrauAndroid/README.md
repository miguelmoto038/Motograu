# Moto Grau 3D — projeto Android

Este é um projeto-fonte Android Studio com um jogo de pilotagem offline embutido em um WebView.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `MotoGrauAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação dos componentes Android solicitados.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- Este ZIP contém o código-fonte do aplicativo, não um APK já compilado.
- O protótipo usa gráficos 3D simples via WebGL e física arcade simulada; não reproduz exatamente o jogo da imagem nem equivale a um simulador profissional.
- O jogo funciona offline depois de instalado.
